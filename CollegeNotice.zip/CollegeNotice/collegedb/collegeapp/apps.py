from django.apps import AppConfig


class CollegeappConfig(AppConfig):
    name = 'collegeapp'
