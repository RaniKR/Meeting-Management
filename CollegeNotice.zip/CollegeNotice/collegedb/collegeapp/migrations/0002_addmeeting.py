

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('collegeapp', '0001_initial'),
    ]

    operations = [
        migrations.CreateModel(
            name='AddMeeting',
            fields=[
                ('id', models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('staffname', models.CharField(blank=True, max_length=200, null=True)),
                ('email_id', models.EmailField(blank=True, max_length=200, null=True)),
                ('meeting_info', models.CharField(blank=True, max_length=200, null=True)),
                ('meeting_date', models.CharField(blank=True, max_length=200, null=True)),
                ('meeting_time', models.CharField(blank=True, max_length=200, null=True)),
            ],
        ),
    ]
