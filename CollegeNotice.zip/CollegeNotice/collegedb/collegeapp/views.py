from django.shortcuts import render
from collegeapp.models import UserLogin
from collegeapp.models import StaffRegistration
from collegeapp.models import AddMeeting
import smtplib
from django.contrib import messages
# Create your views here.

def index(request):
    return render(request,'index.html')


def login(request):
    userdict=AddMeeting.objects.all()
    if request.method == "POST":
        username = request.POST.get('t1', '')
        password = request.POST.get('t2', '')
        request.session['username']=username

        checklogin = UserLogin.objects.filter(username=username).values()
        for a in checklogin:
            utype = a['utype']
            upass= a['password']
            if(upass == password):

                if(utype == "admin"):

                    return render(request,'admin_home.html',context={'msg':'welcome to admin'})
                if(utype == "Faculty"):
                    return render(request, 'staff_home.html',{'userdict':userdict})
                if (utype=="Co-Ordinator"):
                    return render(request,'co_ordinator_home.html')

                if (utype == "Hod"):
                    return render(request, 'hod_home.html')

            else:
                return render(request,'index.html',context={'msg':'invalid entry'})

    return render(request,'index.html')


def addstaff(request):
    if request.method== "POST":
        designation=request.POST.get('t1','')
        staffname = request.POST.get('t2', '')
        dept = request.POST.get('t3', '')
        email = request.POST.get('t4', '')
        contact = request.POST.get('t5', '')
        StaffRegistration.objects.create(designation=designation,staffname=staffname,dept=dept,emailId=email,contactno=contact)
        UserLogin.objects.create(username=email,password=contact,utype=designation)

        content = "username is"+str(email)+" and password is "+str(contact)
        mail = smtplib.SMTP('smtp.gmail.com', 587)
        mail.ehlo()
        mail.starttls()
        mail.login('gk27295@gmail.com', 'girish123')
        mail.sendmail('gk27295@gmail.com', email, content)
        mail.close()
        #messages.add_message(request,messages.INFO,'One record added successfully')
        return render(request,'admin_home.html',{'msg':'added successfully'})


def staff_view(request):
    userdict=StaffRegistration.objects.all()
    return render(request,'staff_view.html',{'userdict':userdict})

def staff_view_c(request):
    userdict=StaffRegistration.objects.filter(designation='Faculty')
    return render(request,'staff_view_c.html',{'userdict':userdict})

def admin_home(request):
    return render(request,'admin_home.html')

def co_ordinator_home(request):
    return render(request,'co_ordinator_home.html')

def meeting(request):
    if request.method=="POST":
        staffname=request.POST.get('t2','')
        email_id=request.POST.get('t4','')
        meeting_info = request.POST.get('t5', '')
        meeting_date = request.POST.get('t6', '')
        meeting_time = request.POST.get('t7', '')

        msg="Meeting will be held on "+str(meeting_date)+" and the subject is "+meeting_info
        AddMeeting.objects.create(staffname=staffname,email_id=email_id,meeting_info=meeting_info,meeting_date=meeting_date,meeting_time=meeting_time)
        content=msg
        mail = smtplib.SMTP('smtp.gmail.com', 587)
        mail.ehlo()
        mail.starttls()
        mail.login('gk27295@gmail.com', 'girish123')
        mail.sendmail('gk27295@gmail.com', email_id, content)
        mail.close()

    return render(request,'meeting.html')



def meeting_del(request):
    if request.method=="POST":
        id=request.POST.get('id')
        udata=AddMeeting.objects.get(id=id)
        udata.delete()
        userdict=AddMeeting.objects.all()
        return render(request,'meeting_view.html',{'userdict':userdict})

def meeting_update(request):
    if request.method=="POST":
        id=request.POST.get('id')
        userdict=AddMeeting.objects.filter(id=id).values()
        return render(request,'meeting_edit.html',{'userdict':userdict})


def meeting_update_h(request):
    if request.method=="POST":
        id=request.POST.get('id')
        userdict=AddMeeting.objects.filter(id=id).values()
        return render(request,'meeting_edit_h.html',{'userdict':userdict})

def meeting_db(request):
    if request.method == "POST":
        id=request.POST.get('id')
        staffname = request.POST.get('t2', '')
        email_id = request.POST.get('t4', '')
        meeting_info = request.POST.get('t5', '')
        meeting_date = request.POST.get('t6', '')
        meeting_time = request.POST.get('t7', '')
        msg = "Meeting will be held on " + str(meeting_date) + " and the subject is " + meeting_info
        AddMeeting.objects.filter(id=id).update(staffname=staffname, email_id=email_id, meeting_info=meeting_info,meeting_date=meeting_date, meeting_time=meeting_time)
        userdict=AddMeeting.objects.all()
        return render(request,'meeting_view.html',{'userdict':userdict})


def meeting_db_h(request):
    if request.method == "POST":
        id=request.POST.get('id')
        staffname = request.POST.get('t2', '')
        email_id = request.POST.get('t4', '')
        meeting_info = request.POST.get('t5', '')
        meeting_date = request.POST.get('t6', '')
        meeting_time = request.POST.get('t7', '')
        msg = "Meeting will be held on " + str(meeting_date) + " and the subject is " + meeting_info
        AddMeeting.objects.filter(id=id).update(staffname=staffname, email_id=email_id, meeting_info=meeting_info,meeting_date=meeting_date, meeting_time=meeting_time)
        userdict=AddMeeting.objects.all()
        return render(request,'meeting_view_h.html',{'userdict':userdict})


def meeting_view(request):
    userdict=AddMeeting.objects.all()
    return render(request,'meeting_view.html',{'userdict':userdict})

def meeting_view_h(request):
    username=request.session['username']
    dept=""
    '''udata=StaffRegistration.objects.filter(emailid=username).values()
    for u in udata:
        dept=u['dept']'''

    userdict=AddMeeting.objects.filter(email_id=username).values()

    return render(request,'meeting_view_h.html',{'userdict':userdict})

def meeting_info_view(request):
    username=request.session['username']
    userdict=AddMeeting.objects.filter(email_id=username).values()
    return render(request,'meeting_info_view.html',{'userdict':userdict})

def forgotpass(request):
    password=""

    if request.method=="POST":
        uname=request.POST.get('username','')

        userdict=UserLogin.objects.filter(username=uname).count()

        if userdict >= 1:
            udata = UserLogin.objects.filter(username=uname).values()
            for uu in udata:
                password=uu['password']
            content = "Your paswword is "+str(password)
            mail = smtplib.SMTP('smtp.gmail.com', 587)
            mail.ehlo()
            mail.starttls()
            mail.login('gk27295@gmail.com', 'girish123')
            mail.sendmail('gk27295@gmail.com', uname, content)
            mail.close()
            return render(request,'index.html',{'msg':'password has been sent to your email'})
        else:
            return render(request,'forgot_pass.html',{'msg':'invalid Username'})
    return render(request,'forgot_pass.html')


def meeting_status(request,pk):
    u=AddMeeting.objects.get(id=pk)
    emailid=u.email_id
    sname=u.staffname

    content = "Faculty" +sname+"is confirm about attending the meeting"
    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.ehlo()
    mail.starttls()
    mail.login('gk27295@gmail.com', 'girish123')
    mail.sendmail('gk27295@gmail.com', 'poojachangoli08@gmail.com', content)
    mail.close()

    return render(request,'staff_home.html')


def meeting_status_a(request,pk):
    u=AddMeeting.objects.get(id=pk)
    emailid=u.email_id
    sname = u.staffname
    content = "Faculty"+ sname+ " is confirm about Not attending the meeting"
    mail = smtplib.SMTP('smtp.gmail.com', 587)
    mail.ehlo()
    mail.starttls()
    mail.login('gk27295@gmail.com', 'girish123')
    mail.sendmail('gk27295@gmail.com', 'poojachangoli08@gmail.com', content)
    mail.close()
    return render(request,'staff_home.html')


def hod_home(request):
    return render(request,'hod_home.html')