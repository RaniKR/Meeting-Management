from django.db import models

class UserLogin(models.Model):
    username = models.CharField(max_length=200,null=True,blank=True)
    password = models.CharField(max_length=50,null=True,blank=True)
    utype = models.CharField(max_length=50,null=True,blank=True)

class StaffRegistration(models.Model):
    designation = models.CharField(max_length=200,null=True,blank=True)
    staffname = models.CharField(max_length=50,null=True,blank=True)
    dept = models.CharField(max_length=50,null=True,blank=True)
    emailId = models.EmailField(max_length=100,null=True,blank=True)
    contactno = models.CharField(max_length=100,null=True,blank=True)

class AddMeeting(models.Model):
    staffname=models.CharField(max_length=200,null=True,blank=True)
    email_id = models.EmailField(max_length=200, null=True, blank=True)
    meeting_info = models.CharField(max_length=200, null=True, blank=True)
    meeting_date = models.CharField(max_length=200, null=True, blank=True)
    meeting_time = models.CharField(max_length=200, null=True, blank=True)
