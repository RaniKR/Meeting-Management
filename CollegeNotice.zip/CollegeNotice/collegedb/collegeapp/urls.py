from django.conf.urls import url

from . import views

urlpatterns=[
    url('^$', views.index, name='index'),
    url('^login/$', views.login, name='login'),
    url('^addstaff/$', views.addstaff, name='addstaff'),
    url('^staff_view/$', views.staff_view, name='staff_view'),
    url('^staff_view_c/$', views.staff_view_c, name='staff_view_c'),
    url('^admin_home/$', views.admin_home, name='admin_home'),
    url('^hod_home/$', views.hod_home, name='hod_home'),
    url('^co_ordinator_home/$', views.co_ordinator_home, name='co_ordinator_home'),
    url('^meeting/$', views.meeting, name='meeting'),
    url('^meeting_view/$', views.meeting_view, name='meeting_view'),
    url('^meeting_view_h/$', views.meeting_view_h, name='meeting_view_h'),
    url('^meeting_info_view/$', views.meeting_info_view, name='meeting_info_view'),
    url('^forgotpass/$', views.forgotpass, name='forgotpass'),
    url('^meeting_del/$', views.meeting_del, name='meeting_del'),
    url('^meeting_update/$', views.meeting_update, name='meeting_update'),
    url('^meeting_update_h/$', views.meeting_update_h, name='meeting_update_h'),
    url('^meeting_db/$', views.meeting_db, name='meeting_db'),
    url('^meeting_db_h/$', views.meeting_db_h, name='meeting_db_h'),
    url('^meeting_status/(?P<pk>\d+)/$', views.meeting_status, name='meeting_status'),
    url('^meeting_status_a/(?P<pk>\d+)/$', views.meeting_status_a, name='meeting_status_a'),
]